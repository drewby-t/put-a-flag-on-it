How do you conquer a whole planet?
Well that's easy to answer...
# Put A Flag on it!
haxejam 2021 project
